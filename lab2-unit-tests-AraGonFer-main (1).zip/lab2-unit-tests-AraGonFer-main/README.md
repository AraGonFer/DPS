# dps-laboratory2
Este proyecto implementa funciones en C++ y pruebas unitarias asociadas. Esta prueba fue hecha en Ubuntu 20.04.

## Prerrequisitos
Antes de compilar y ejecutar este proyecto, asegúrate de tener lo siguiente instalado:

- **CMake:** Si no lo tienes instalado, puedes descargarlo usando:
  
sudo apt-get install cmake
  
- **Compilador de C++:** En Linux, puedes usar `g++` u otro compilador compatible usando:
  
sudo apt-get install g++ 

- **GTest:** Para instalar Google Test (gtest) en un sistema basado en Debian/Ubuntu, puedes usar el siguiente comando:

sudo apt-get install libgtest-dev

## Instrucciones de Compilación y Ejecución

1. **Descarga del Proyecto:**
   - Descarga el [archivo ZIP del proyecto] desde <>Code en (https://github.com/ULE-Informatica-2023-2024/lab2-unit-tests-AraGonFer/archive/refs/heads/main.zip).
   - Descomprime el archivo ZIP en el directorio de tu elección.
2. 
3. **Compilación y Ejecución:**
   ```bash
   # Abre una terminal y navega al directorio del proyecto
   cd /tu/ruta/del/directorio/descomprimido/

   # Crea y navega al directorio de compilación
   mkdir build
   cd build

   # Configura y compila el proyecto
   cmake ..
   cmake --build .

   # Ejecuta las pruebas
   ./runTests


**Descripción de las Pruebas**

1. **`wrapAddFunctionTest.NonWrappingNums`**:
   - **Objetivo:** Verificar que la función `wrapFunctionAdd` maneje adecuadamente la suma de dos números sin desbordamiento.
   - **Caso de Prueba:** Se suman los números 3 y 6 (`wrapFunctionAdd(3, 6)`).

2. **`wrapAddFunctionTest.WrappingNums`**:
   - **Objetivo:** Verificar que la función `wrapFunctionAdd` maneje adecuadamente la suma de dos números que resulta en un desbordamiento.
   - **Caso de Prueba:** Se suma el valor máximo representable por un `unsigned int` (`UINT_MAX`) y 1 (`wrapFunctionAdd(UINT_MAX, 1)`).

3. **`wrapMulFunctionTest.NonWrappingMulNums`**:
   - **Objetivo:** Verificar que la función `wrapFunctionMul` maneje adecuadamente la multiplicación de dos números sin desbordamiento.
   - **Caso de Prueba:** Se multiplican los números 3 y 6 (`wrapFunctionMul(3, 6)`).

4. **`wrapMulFunctionTest.WrappingMulNums`**:
   - **Objetivo:** Verificar que la función `wrapFunctionMul` maneje adecuadamente la multiplicación de dos números que resulta en un desbordamiento.
   - **Caso de Prueba:** Se multiplica el valor máximo representable por un `unsigned int` (`UINT_MAX`) por sí mismo (`wrapFunctionMul(UINT_MAX, UINT_MAX)`).

5. **`wrapShiftFunctionTest.NonWrappingMulBNums`**:
   - **Objetivo:** Verificar que la función `wrapFunctionShift` maneje adecuadamente el desplazamiento sin desbordamiento.
   - **Caso de Prueba:** Se realiza un desplazamiento a la izquierda del número 2 por 1 bit (`wrapFunctionShift(2, 1)`).

6. **`wrapShiftFunctionTest.WrappingMulBNums`**:
   - **Objetivo:** Verificar que la función `wrapFunctionShift` maneje adecuadamente el desplazamiento que resulta en un desbordamiento.
   - **Caso de Prueba:** Se realiza un desplazamiento a la izquierda del valor máximo representable por un `uint32_t` (`UINT_MAX`) por 12 bits (`wrapFunctionShift(UINT_MAX, 12)`).


